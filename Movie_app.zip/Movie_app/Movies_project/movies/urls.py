from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.create_movies, name='create_movies'),
    path('list/', views.movies_list, name='movies_list'),
    path('<int:movie_id>/', views.view_movies, name='view_movies'),
    path('<int:movie_id>/update/', views.update_movies, name='update_movies'),
    path('<int:movie_id>/delete/', views.delete_movies, name='delete_movies'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
