from django.shortcuts import render, redirect, get_object_or_404
from .models import Movie
from .forms import MovieForm
from django.contrib.auth.decorators import login_required

@login_required
def create_movies(request):
    if request.method == 'POST':
        form = MovieForm(request.POST, request.FILES)
        if form.is_valid():
            Movie = form.save(commit=False)
            Movie.user = request.user
            Movie.save()
            return redirect('movies_list')
    else:
        form = MovieForm()
    return render(request, 'movies/create_movies.html', {'form': form})

@login_required
def movies_list(request):
    movies = Movie.objects.filter(user=request.user)
    return render(request, 'movies/movies_list.html', {'movies': movies})

@login_required
def view_movies(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    return render(request, 'movies/view_movies.html', {'movie': movie})

@login_required
def update_movies(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    if request.method == 'POST':
        form =MovieForm(request.POST, request.FILES, instance=movie)
        if form.is_valid():
            form.save()
            return redirect('movies_list')
    else:
        form = MovieForm(instance=movie)
    return render(request, 'movies/update_movies.html', {'form': form})

@login_required
def delete_movies(request, movie_id):
    movie = get_object_or_404(Movie, id=movie_id)
    if request.method == 'POST':
        movie.delete()
        return redirect('movies_list')
    return render(request, 'movies/delete_movies.html', {'movie': movie})
