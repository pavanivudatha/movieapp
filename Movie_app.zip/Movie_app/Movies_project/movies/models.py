from django.db import models
from django.contrib.auth.models import User

class Movie(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField()
    poster = models.ImageField(upload_to='movie_posters/', blank=True, null=True)
    genre = models.CharField(max_length=50)
    year_of_release = models.IntegerField()
    duration = models.IntegerField()
    cast = models.CharField(max_length=200)
    crew = models.CharField(max_length=200)
    rating = models.DecimalField(max_digits=3, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)



    def __str__(self):
        return self.name